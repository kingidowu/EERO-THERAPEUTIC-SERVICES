# Eero backend foundation

This is an implemented, locally testable service layer for the Eero workspace. It is **not a certified HIPAA system** and is **not connected to the hosted prototype**. Real patient ingestion is disabled in this adapter. Do not put real patient data into the frontend or this development database.

## Implemented

- Organization isolation, active staff membership, roles, and case assignments checked in the service layer.
- Cases, quarantined documents, separate note types, tasks, authorization evidence, and append-only development audit history.
- AES-256-GCM encryption of case labels, document titles/content, note bodies, and task titles. Authentication data binds ciphertext to its organization and record.
- Uploaded PDF/JPEG/PNG size and signature checks. All files start quarantined; reads and approvals fail until a trusted scanner result is recorded.
- Separate reviewer approval; psychotherapy note reads restricted to their author. Disclosure exceptions are deliberately not implemented.
- Deterministic operational summary for pending reviews, overdue tasks, and expired authorization records. No clinical recommendations, AI inference, or automatic disclosures.
- Test coverage for cross-organization and unassigned-case access, revoked staff, encryption tampering, quarantine, separation of duties, note isolation, audit immutability, and operational rules.

## Run with fictional information

Create a virtual environment and install `requirements.txt`, then run from this folder:

```bash
python -m unittest discover -s tests -v
```

There is no HTTP server, public credential, or authentication bypass. `Principal` must eventually be constructed exclusively from a validated identity-provider session, never untrusted client fields. Staff provisioning in tests uses a fixture; a production administrative provisioning adapter still needs to be built.

## Production database and storage design

Use a managed PostgreSQL database for relationships, transactions, indexed queries, and organization isolation. Store file bodies in a private object store rather than database rows. The SQLite adapter is only for development checks; it has not been load-tested and must not be described as a large production database.

The intended record model includes organizations, staff membership, clients, guardian relationships, cases, staff assignments, referrals, service authorizations, encounters, treatment plans, versioned progress notes, separately restricted psychotherapy notes, documents and file versions, consent/disclosure evidence, programs/enrollments, tasks, approved billing events, access/disclosure history, and a durable job queue.

The implemented subset is defined by `schema.sql`. `postgres_blueprint.sql` supplies a broader PostgreSQL schema for clients, guardian evidence, encounters, document versions, progress notes, psychotherapy notes, programs, enrollments, tasks, authorizations, and audit events. It has not been applied or integration-tested. Row-level security is enabled and forced without permissive policies, so a correctly configured non-owner application role is denied access until reviewed policies are supplied. The broader modules remain planned service functionality. Before production, require organization-specific and case-specific row-level policies and a least-privilege database role; use pooling; implement pagination and concurrent mutation checks; keep audit access separate from clinical records. A tenant parameter alone is insufficient protection without an authenticated membership boundary.

For a photographed form, the production sequence is authenticated upload → size/signature verification → encrypted quarantine object → malware scan → approved OCR service → extraction draft → staff review → versioned record. OCR must not automatically overwrite verified clinical records. File names, request bodies, signed URLs, and clinical text must never enter ordinary application logs. Object keys use opaque IDs. Use short-lived signed access links after server authorization, not publicly readable buckets. Camera capture should avoid storing documents in device photo galleries wherever the browser permits it.

## Required before any patient-data launch

1. Eero identifies its responsible privacy/security officials and confirms the data types, workflows, jurisdictions, client age groups, and applicable contracts. Review New Jersey confidentiality/minor and guardian access requirements and assess whether 42 CFR Part 2 applies. Do not treat ordinary consent as blanket authorization for restricted disclosures.
2. Execute applicable BAAs with every provider/subprocessor handling ePHI. Verify the specific services, plans, locations, support access, and contract coverage. No BAA has been verified for the current demo hosting.
3. Integrate a validated identity provider with MFA, revocation, timeout/lock controls, least-privilege roles, staff onboarding/offboarding, and verified per-case access. Implement and review exceptional access procedures; do not automatically give administrators psychotherapy note access.
4. Configure managed encryption keys, secret management and rotation; TLS-only database/API connections; private networking where appropriate; restrictive storage/IAM rules; and separation between development and production.
5. Integrate trusted malware scanning, OCR, queue workers, retry/idempotency handling, upload cleanup, and tested review/versioning workflows. No external AI processor receives PHI until approved agreements, purpose limitations, and data controls are verified.
6. Implement durable audit export with restricted append-only access and independently retained immutable copies. The SQLite hash chain is for development validation; a database administrator can defeat it, and it is not a production immutability guarantee. Audit failed access attempts at the authenticated gateway without logging PHI.
7. Implement and test encrypted backups, restore drills, recovery objectives, retention/legal holds, authorized deletion, incident response and breach handling, monitoring, rate limits, vulnerability management, and independent penetration testing.
8. Implement patient access/amendment/disclosure workflows, guardian authorization, restricted-record segmentation, electronic signature verification where applicable, and approved clinical forms. Authorization metadata does not establish legal validity by itself.
9. Complete a documented risk analysis and remediation review, organizational policies and staff training, and clinical/privacy/security review of the complete deployed system. Verify backup and logs providers as well as primary database vendors.
10. Enable real-patient ingestion only in a separately reviewed production adapter. The local adapter's safety lock is not a compliance attestation.

## Validation limits

Current checks cover the local Python service layer, not live identity, hosted PostgreSQL, backup recovery, storage security, clinical usability, regulatory certification, or capacity. Audit actions contain opaque IDs but those identifiers and metadata must still be treated as sensitive. Local SQLite stores some metadata unencrypted; production must encrypt its full storage and backups. Development keys come from test memory; production key provisioning is not implemented.

## Primary references

- HHS cloud computing guidance: https://www.hhs.gov/hipaa/for-professionals/special-topics/health-information-technology/cloud-computing/index.html
- HHS Security Rule summary: https://www.hhs.gov/hipaa/for-professionals/security/laws-regulations/index.html
- HHS mental health and psychotherapy note protections: https://www.hhs.gov/hipaa/for-professionals/faq/does-hipaa-provide-extra-protections-mental-health-information-compared-other-health.html

These references guide the design. They do not establish that this implementation is compliant or approved.

## AI adapter and role previews

`ai_adapter.py` provides local, sample-data-only OpenAI Responses adapters for PNG/JPEG extraction and structured clinician-review briefings. Every extracted field requires review; extraction never automatically changes a chart. The briefing excludes contact fields and does not establish diagnoses. It requires an explicit fictional-data flag and an API key in an ignored `.env.local` or environment variable. The hosted static preview does not call this adapter and presents its extraction example as a sample. The 24 development tests and a live fictional briefing smoke check passed.

The frontend contains client intake, intake routing and assignment, clinical chart tabs, reported medication/allergy lists, draft SOAP/DAP notes, encounters, and care goals. These are browser-local prototype features. Role buttons are previews, not identity or authorization controls. No frontend intake syncs to the development database.

## Client experience preview

The default entry page now introduces the client preview with a separate staff-workspace link. The client home has four sections: Home, Intake form, Documents, and My request. Client request lists show only submissions tracked as created through this browser's client preview. Later attachments are placed with the existing intake; for assigned requests they also enter the case's document-review queue. No account authentication or per-user server-side data isolation is implied. Four frontend flow tests cover request filtering, upload rejection, assigned-case routing, and storage-failure rollback.
